// export interface OrganizeEventDetail {
//   slug : string;
//   title: string;
//   date : string;
//   time : string;

//   location: {
//     platform       : string;
//     platformStatus?: string;
//     name?          : string;
//     url?           : string;
//     streamUrl?     : string;
//     owner?         : string;
//     ownerUrl?      : string;
//   };

//   group?: {
//     name: string;
//     url?: string;
//   };

//   announceUrls?: {
//     label: string;
//     url  : string;
//   }[];
//   flyerImage? : string;
//   hashtag?    : string;

//   timetables: {
//     floor: string;
//     entries: {
//       time  : string;
//       name: string;
//       role: string;
//       url?: string;
//     }[]
//   }[];

//   collabos?: {
//     name: string;
//     url?: string;
//   }[];
// }