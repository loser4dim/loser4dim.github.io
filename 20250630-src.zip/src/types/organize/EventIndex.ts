// export interface OrganizeHistoryEvent {
//   title: string;
//   day  : string;
//   slug?: string;
// };

// export interface OrganizeMonthGroup {
//   month : string;
//   events: OrganizeHistoryEvent[];
// };

// export interface OrganizeYearGroup {
//   year  : string;
//   months: OrganizeMonthGroup[];
// };