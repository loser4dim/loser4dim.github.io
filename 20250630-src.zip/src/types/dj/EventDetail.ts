// export interface EventDetail {
//   slug: string;
//   title: string;
//   date: string;
//   location?: {
//     platform?: string;
//     name?: string;
//     url?: string;
//   };

//   organizer?: {
//     name: string;
//     url: string;
//   };
//   noticeUrl?: string;
//   group?: {
//     name: string;
//     url?: string;
//   };
  
//   hashtag?: string;
//   flyerImage?: string;

//   timetable: {
//     time: string;
//     dj: string;
//     djUrl?: string;
//     vj?: string;
//     vjUrl?: string;
//   }[];

//   mix?: {
//     type: "soundcloud" | "mixcloud" | "youtube";
//     url: string;
//     embedUrl: string;
//   };

//   setlist?: {
//     index: string,
//     artist: string;
//     track: string;
//     url?: string;
//   }[];
// }