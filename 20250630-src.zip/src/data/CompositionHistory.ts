// export const compositionHistory = [
//   {
//     year: "2024",
//     works: [
//       {
//         title: "hoarfrost",
//         url: "https://loser4dim.bandcamp.com/album/hoarfrost",
//         label: "V.A.",
//         released: "2024年1月17日"
//       },
//       {
//         title: "remind",
//         url: "https://loser4dim.bandcamp.com/album/remind",
//         label: "V.A.",
//         released: "2024年3月1日"
//       },
//       {
//         title: "Midnight Residents",
//         url: "https://linkco.re/GqSrnrhv",
//         label: "Electrosheep Records",
//         released: "2024年3月18日"
//       },
//       {
//         title: "GOOD INTERNET 2",
//         url: "https://goodinternet.booth.pm/items/6185822",
//         label: "GOOD INTERNET",
//         released: "2024年10月27日"
//       },
//       {
//         title: "Midnight Residents 2",
//         url: "https://linkco.re/Zeft15ED",
//         label: "Electrosheep Records",
//         released: "2024年11月18日"
//       },
//       {
//         title: "4x4 lintel",
//         url: "https://linkco.re/GqSrnrhv",
//         label: "V.A.",
//         released: "2024年12月27日"
//       }
//     ]
//   }
// ];