// import {OrganizeYearGroup} from "@/types/organize/EventIndex";

// export const organizeHistory: OrganizeYearGroup[] = [
//   {
//     year  : "2021",
//     months: [
//       {
//         month : "12",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "27",
//             slug : "chill-1"
//           }
//         ]
//       }
//     ]
//   },
//   {
//     year  : "2022",
//     months: [
//       {
//         month : "01",
//         events: [
//           {
//             title: "【DJ求ム！】俺たちだってPJしたい！",
//             day  : "07",
//             slug : "organize-pj-1"
//           },
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "28",
//             slug : "organize-chill-2"
//           }
//         ]
//       },
//       {
//         month : "02",
//         events: [
//           {
//             title: "【DJ求ム！】俺たちだってPJしたい！ おかわり",
//             day  : "11",
//             slug : "organize-pj-2"
//           },
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "18",
//             slug : "organize-chill-3"
//           }
//         ]
//       },
//       {
//         month : "04",
//         events: [
//           {
//             title: "【DJ求ム！】俺たちだってPJしたい！ おかわり 3杯目 え！PJも募集するですって！？",
//             day  : "02",
//             slug : "organize-pj-3"
//           },
//           {
//             title: "BIRTH OF LOSER Day1",
//             day  : "27",
//             slug : "organize-bitrh-1-1"
//           },
//           {
//             title: "BIRTH OF LOSER Day2",
//             day  : "28",
//             slug : "organize-bitrh-1-2"
//           },
//           {
//             title: "BIRTH OF LOSER Day3",
//             day  : "29",
//             slug : "organize-bitrh-1-3"
//           },
//           {
//             title: "BIRTH OF LOSER Day4",
//             day  : "30",
//             slug : "organize-bitrh-1-4"
//           }
//         ]
//       },
//       {
//         month : "07",
//         events: [
//           {
//             title: "【DJ求ム！】俺たちだってPJしたい！ おかわり 4杯目 どうも、お久し振りです。",
//             day  : "01",
//             slug : "organize-pj-4"
//           }
//         ]
//       },
//       {
//         month : "11",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "11",
//             slug : "organize-chill-4"
//           }
//         ]
//       },
//       {
//         month : "12",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "16",
//             slug : "organize-chill-5"
//           }
//         ]
//       }
//     ]
//   },
//   {
//     year  : "2023",
//     months: [
//       {
//         month : "01",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "13",
//             slug : "organize-chill-6"
//           }
//         ]
//       },
//       {
//         month : "02",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "13",
//             slug : "organize-chill-7"
//           }
//         ]
//       },
//       {
//         month : "03",
//         events: [
//           {
//             title: "MusicStellarLake Friday Collab.",
//             day  : "24",
//             slug : "organize-collab-1"
//           }
//         ]
//       },
//       {
//         month : "04",
//         events: [
//           {
//             title: "\"BIRTHDAY PARTY\" in Layer 0.0.0",
//             day  : "30",
//             //slug : "organize-bitrh-2"
//           }
//         ]
//       },
//       {
//         month : "12",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "02",
//             slug : "organize-chill-8"
//           }
//         ]
//       }
//     ]
//   },
//   {
//     year  : "2024",
//     months: [
//       {
//         month : "02",
//         events: [
//           {
//             title: "vs Mano.Hsmt",
//             day  : "23",
//             slug : "organize-collab-2"
//           }
//         ]
//       },
//       {
//         month : "03",
//         events: [
//           {
//             title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//             day  : "19",
//             slug : "organize-chill-9"
//           }
//         ]
//       },
//       {
//         month : "04",
//         events: [
//           {
//             title: "\"BIRTHDAY PARTY\" in Layer 0.0.0",
//             day  : "30",
//             //slug : "organize-bitrh-3"
//           }
//         ]
//       }
//     ]
//   },
//   {
//     year  : "2025",
//     months: [
//       {
//         month : "04",
//         events: [
//           {
//             title: "\"BIRTHDAY PARTY\" in Layer 0.0.0",
//             day  : "30",
//             //slug : "organize-bitrh-4"
//           }
//         ]
//       }
//     ]
//   }
// ];