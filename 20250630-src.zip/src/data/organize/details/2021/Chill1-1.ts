// import { OrganizeEventDetail } from "@/types/organize/EventDetail";

// export const event: OrganizeEventDetail = {
//   slug : "chill-1",
//   title: "今日のジャンルですか？DJがチルと言えばチルですね。",
//   date : "2021-12-27",
//   time : "20:45-25:00",
//   location: {
//     platform: "VRChat",
//     platformStatus: "Friends+",
//     name          : "Music Stellar Lake",
//     url           : "https://vrchat.com/home/world/wrld_c330cf97-4ffb-40a9-b872-79a36905134d/info",
//     owner         : "m1chie",
//     ownerUrl      : "https://x.com/m1chie_0408"
//   },
//   announceUrls: [
//     {
//       label: "X/Twitter",
//       url  : "https://x.com/loser4dim/status/1473611641657098249"
//     }
//   ],
//   flyerImage: "/organize/2021/chill-1.webp",
//   hashtag   : "#チル言 #MusicStellarLake #VRChat",
//   timetables: [
//     {
//       floor: "Main",
//       entries: [
//         {
//           time: "21:00-21:50",
//           name: "ZERØ(ぜろ)",
//           role: "dj",
//           url : "https://x.com/kaketemowattemo"
//         },
//         {
//           time: "21:50-22:35",
//           name: "すなもりあらた",
//           role: "dj",
//           url : "https://piku.page/@damuneco299"
//         },
//         {
//           time: "22:35-23:20",
//           name: "Nicoman",
//           role: "dj",
//           url : "https://bento.me/nicoman"
//         },
//         {
//           time: "23:20-25:00",
//           name: "vcfox",
//           role: "dj",
//           url : "https://vcfox.xyz/contact/"
//         }
//       ]
//     }
//   ]
// };