// import { event as organize1 } from "@/data/organize/details/2021/Chill1-1";

// export const allOrganizeEvents = [
//   organize1
// ];