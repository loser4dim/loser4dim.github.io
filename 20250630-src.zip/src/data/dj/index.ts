// export const DJ_History = [
//   {
//     year: "2022",
//     events: [
//       {
//         slug: "v-1",
//         title: "DJガチ初心者練習会",
//         url: "",
//         platform: "VRChat",
//         date: "2022年2月12日",
        
//       },
//       {
//         slug: "v-2",
//         title: "DJなんもわからん EP.7",
//         url: "",
//         platform: "VRChat",
//         date: "2022年3月3日",
        
//       },
//       {
//         title: "Club&Bar羽ばたき",
//         url: "",
//         platform: "VRChat",
//         date: "2022年3月13日",
//       slug: ""
//       },
//       {
//         title: "Rookies Sound Festa",
//         url: "",
//         platform: "VRChat",
//         date: "2022年3月18日",
//       slug: ""
//       },
//       {
//         title: "GZ 10th",
//         url: "",
//         platform: "VRChat",
//         date: "2022年4月1日",
//       slug: ""
//       },
//       {
//         title: "m1chie Birthday",
//         url: "",
//         platform: "VRChat",
//         date: "2022年4月8日",
//       slug: ""
//       },
//       {
//         title: "Sunday Live Party",
//         url: "",
//         platform: "VRChat",
//         date: "2022年4月17日",
//       slug: ""
//       },
//       {
//         title: "Quest Danceparty Club No.62",
//         url: "",
//         platform: "VRChat",
//         date: "2022年4月26日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 104th",
//         url: "",
//         platform: "VRChat",
//         date: "2022年5月9日",
//       slug: ""
//       },
//       {
//         title: "JUKe FfAI(r)Y",
//         url: "",
//         platform: "VRChat",
//         date: "2022年5月15日",
//       slug: ""
//       },
//       {
//         title: "BreakTheSleeplessNight PoC.1",
//         url: "",
//         platform: "VRChat",
//         date: "2022年5月20日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年5月27日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月1日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.18",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月9日",
//       slug: ""
//       },
//       {
//         title: "翔-KAKERU- Vol.20",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月16日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ Vol.4",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月17日",
//       slug: ""
//       },
//       {
//         title: "PNGミュージアム エンディング・ナイト",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月18日",
//       slug: ""
//       },
//       {
//         title: "Live House \"Novice\" 第61回",
//         url: "https://x.com/LHNovice/status/1536748361956544513",
//         platform: "VRChat",
//         date: "2022年6月18日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月22日",
//       slug: ""
//       },
//       {
//         title: "Club Plane 2",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月24日",
//       slug: ""
//       },
//       {
//         title: "Under Sea Music Event",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月25日",
//       slug: ""
//       },
//       {
//         title: "mellon afterlives #096",
//         url: "",
//         platform: "VRChat",
//         date: "2022年6月30日",
//       slug: ""
//       },
//       {
//         title: "ELECTRO NURSERY SCHOOL-エレクトロ保育園- Vol.2",
//         url: "https://x.com/Yabuchan0913_VR/status/1545206732854800384",
//         platform: "VRChat - カルチャーセンター - 代打",
//         date: "2022年7月9日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "VRChat",
//         date: "2022年7月13日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年7月22日",
//       slug: ""
//       },
//       {
//         title: "雑ボカ。第3回",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月2日",
//       slug: ""
//       },
//       {
//         title: "Interstellar HOUSE Night",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月4日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月17日",
//       slug: ""
//       },
//       {
//         title: "mellon afterlives #103",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月18日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 119th",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月22日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年8月27日",
//       slug: ""
//       },
//       {
//         title: "ミュージックスクランブル -AROMERICANDINERせんりょう作戦-",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月2日",
//       slug: ""
//       },
//       {
//         title: "Live House \"Novice\" 第71回",
//         url: "https://x.com/LHNovice/status/1563890234672103425",
//         platform: "VRChat",
//         date: "2022年9月3日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月14日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.32",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月15日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ Vol.7",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月16日",
//       slug: ""
//       },
//       {
//         title: "Bar羽休め HOUSE会 第8回",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月17日",
//       slug: ""
//       },
//       {
//         title: "mellons afterlives #107",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月22日",
//       slug: ""
//       },
//       {
//         title: "Bar曲宴",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月23日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年9月24日",
//       slug: ""
//       },
//       {
//         title: "VRC Japan Event Festival (Absence)",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月1日",
//       slug: ""
//       },
//       {
//         title: "Club&Bar羽ばたき Techno Night",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月2日",
//       slug: ""
//       },
//       {
//         title: "KYUUB",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月15日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月21日",
//       slug: ""
//       },
//       {
//         title: "mellon afterlives #112",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月27日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研リアル課外活動",
//         url: "",
//         platform: "",
//         date: "2022年10月29日",
//       slug: ""
//       },
//       {
//         title: "Sweets Party in Sweet Dish! Vol.2 HALLOWEEN PARTY",
//         url: "",
//         platform: "VRChat",
//         date: "2022年10月30日",
//       slug: ""
//       },
//       {
//         title: "TYLE",
//         url: "",
//         platform: "VRChat",
//         date: "2022年11月5日",
//       slug: ""
//       },
//       {
//         title: "第22回広義民族音楽イベント Mysnic Music of the World",
//         url: "",
//         platform: "VRChat",
//         date: "2022年11月24日",
//       slug: ""
//       },
//       {
//         title: "PRIVATE EVENT",
//         url: "",
//         platform: "",
//         date: "2022年11月25日",
//       slug: ""
//       },
//       {
//         title: "mellon afterlives #117",
//         url: "",
//         platform: "",
//         date: "2022年12月1日",
//       slug: ""
//       },
//       {
//         title: "Re:FLaT",
//         url: "",
//         platform: "",
//         date: "2022年12月7日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.43",
//         url: "",
//         platform: "",
//         date: "2022年12月8日",
//       slug: ""
//       },
//       {
//         title: "GaMe語り",
//         url: "",
//         platform: "",
//         date: "2022年12月10日",
//       slug: ""
//       },
//       {
//         title: "面喰",
//         url: "",
//         platform: "",
//         date: "2022年12月11日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2022年12月21日",
//       slug: ""
//       },
//       {
//         title: "空の鯨",
//         url: "",
//         platform: "",
//         date: "2022年12月23日",
//       slug: ""
//       },
//       {
//         title: "KYUUB",
//         url: "",
//         platform: "",
//         date: "2022年12月24日",
//       slug: ""
//       },
//     ]
//   },
//   {
//     year: "2023",
//     events: [
//       {
//         title: "MUSICBARSSC",
//         url: "",
//         platform: "",
//         date: "2022年1月8日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.11",
//         url: "",
//         platform: "",
//         date: "2022年1月20日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 142nd",
//         url: "",
//         platform: "",
//         date: "2022年1月30日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2022年2月1日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #127",
//         url: "",
//         platform: "",
//         date: "2022年2月16日",
//       slug: ""
//       },
//       {
//         title: "130BPM±8% 25.7 WINTER WEEKEND 2nd Day.7",
//         url: "",
//         platform: "",
//         date: "2022年2月17日",
//       slug: ""
//       },
//       {
//         title: "Unstable Hologram",
//         url: "",
//         platform: "",
//         date: "2022年2月21日",
//       slug: ""
//       },
//       {
//         title: "Live House \"Novice\" 第95回",
//         url: "https://x.com/LHNovice/status/1628376683157000193",
//         platform: "VRChat",
//         date: "2023年2月25日",
//       slug: ""
//       },
//       {
//         title: "メディテラVR リアルインスタンス",
//         url: "https://x.com/CocciVR/status/1596332352099450880",
//         url2: "https://twipla.jp/events/545545",
//         platform: "津田沼メディテラネオ",
//         date: "2023年2月26日",
//       slug: ""
//       },
//       {
//         title: "あきぺとかげ誕生（前夜）祭",
//         url: "",
//         platform: "",
//         date: "2023年3月1日",
//       slug: ""
//       },
//       {
//         title: "第十一回 創奏音楽祭 Day 1",
//         url: "",
//         platform: "",
//         date: "2023年3月3日",
//       slug: ""
//       },
//       {
//         title: "電フェス2023",
//         url: "",
//         platform: "",
//         date: "2023年3月3日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2023年3月8日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "",
//         date: "2023年3月14日",
//       slug: ""
//       },
//       {
//         title: "第27回広義民族音楽オンリーイベント Mysnic Music of the World",
//         url: "",
//         platform: "",
//         date: "2023年3月22日",
//       slug: ""
//       },
//       {
//         title: "Feel Free A-Remix vol.3",
//         url: "",
//         platform: "",
//         date: "2023年3月29日",
//       slug: ""
//       },
//       {
//         title: "第38回 黒孔雀",
//         url: "",
//         platform: "",
//         date: "2023年3月30日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2023年4月5日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #134",
//         url: "",
//         platform: "",
//         date: "2023年4月6日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.14",
//         url: "",
//         platform: "",
//         date: "2023年4月7日",
//       slug: ""
//       },
//       {
//         title: "m1chie Birthday",
//         url: "",
//         platform: "",
//         date: "2023年4月8日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.63",
//         url: "",
//         platform: "",
//         date: "2023年4月27日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #140",
//         url: "",
//         platform: "",
//         date: "2023年5月18日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 159th",
//         url: "",
//         platform: "",
//         date: "2023年5月29日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研 (Absence)",
//         url: "",
//         platform: "",
//         date: "2023年5月31日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.18",
//         url: "",
//         platform: "",
//         date: "2023年6月2日",
//       slug: ""
//       },
//       {
//         title: "終末旅行がはじまるぞ 7",
//         url: "",
//         platform: "",
//         date: "2023年6月7日",
//       slug: ""
//       },
//       {
//         title: "Schirmer Home Party 2nd Anniversary at RIPPLE",
//         url: "",
//         platform: "",
//         date: "2023年6月9日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年6月11日",
//       slug: ""
//       },
//       {
//         title: "メジャーポッターとjustの部屋",
//         url: "",
//         platform: "",
//         date: "2023年6月18日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2023年7月5日",
//       slug: ""
//       },
//       {
//         title: "MUNI vol.3",
//         url: "",
//         platform: "",
//         date: "2023年7月13日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "",
//         date: "2023年7月14日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlive #150",
//         url: "",
//         platform: "",
//         date: "2023年7月27日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年7月29日",
//       slug: ""
//       },
//       {
//         title: "THE OUTSIDE 2nd Anniversary Rave Day 1",
//         url: "",
//         platform: "",
//         date: "2023年7月31日",
//       slug: ""
//       },
//       {
//         title: "Club&Bar羽ばたき",
//         url: "",
//         platform: "",
//         date: "2023年8月2日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.77",
//         url: "",
//         platform: "",
//         date: "2023年8月3日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 169th",
//         url: "",
//         platform: "",
//         date: "2023年8月7日",
//       slug: ""
//       },
//       {
//         title: "カゲプロ・ボカロ改変交流会",
//         url: "",
//         platform: "",
//         date: "2023年8月15日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年8月18日",
//       slug: ""
//       },
//       {
//         title: "FOOTWORKIN IN VRC",
//         url: "",
//         platform: "",
//         date: "2023年8月19日",
//       slug: ""
//       },
//       {
//         title: "沈淪 vol.4",
//         url: "",
//         platform: "",
//         date: "2023年8月20日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #154",
//         url: "",
//         platform: "",
//         date: "2023年8月24日",
//       slug: ""
//       },
//       {
//         title: "ElectroLiVR vol.28",
//         url: "",
//         platform: "",
//         date: "2023年8月27日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年8月27日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2023年8月30日",
//       slug: ""
//       },
//       {
//         title: "第十三回 創奏音楽祭 Day 2",
//         url: "",
//         platform: "",
//         date: "2023年9月2日",
//       slug: ""
//       },
//       {
//         title: "Chill Moon",
//         url: "",
//         platform: "",
//         date: "2023年9月13日",
//       slug: ""
//       },
//       {
//         title: "第52回 黒孔雀",
//         url: "",
//         platform: "",
//         date: "2023年9月14日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.24",
//         url: "",
//         platform: "",
//         date: "2023年9月15日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "",
//         date: "2023年9月20日",
//       slug: ""
//       },
//       {
//         title: "VOCALOID×SCRAMBLE vol.18",
//         url: "",
//         platform: "",
//         date: "2023年9月21日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年9月23日",
//       slug: ""
//       },
//       {
//         title: "第33回広義民族音楽オンリーイベント Mysnic Music of the World",
//         url: "",
//         platform: "",
//         date: "2023年9月27日",
//       slug: ""
//       },
//       {
//         title: "XIMER-A vol.07",
//         url: "",
//         platform: "",
//         date: "2023年9月29日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #160",
//         url: "",
//         platform: "",
//         date: "2023年10月5日",
//       slug: ""
//       },
//       {
//         title: "リアルテスト家ンザー",
//         url: "",
//         platform: "",
//         date: "2023年10月7日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2023年10月11日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 179th",
//         url: "",
//         platform: "",
//         date: "2023年10月16日",
//       slug: ""
//       },
//       {
//         title: "Rizumu Saturday",
//         url: "",
//         platform: "",
//         date: "2023年10月22日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 180th 拡大版",
//         url: "",
//         platform: "",
//         date: "2023年10月23日",
//       slug: ""
//       },
//       {
//         title: "OK,Garage",
//         url: "",
//         platform: "",
//         date: "2023年10月25日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.29",
//         url: "",
//         platform: "",
//         date: "2023年10月27日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.30",
//         url: "",
//         platform: "",
//         date: "2023年11月3日",
//       slug: ""
//       },
//       {
//         title: "深淵",
//         url: "",
//         platform: "",
//         date: "2023年11月4日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.91",
//         url: "",
//         platform: "",
//         date: "2023年11月9日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #166",
//         url: "",
//         platform: "",
//         date: "2023年11月16日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2023年11月19日",
//       slug: ""
//       },
//       {
//         title: "Future Nova vol.18",
//         url: "",
//         platform: "",
//         date: "2023年12月6日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #170",
//         url: "",
//         platform: "",
//         date: "2023年12月14日",
//       slug: ""
//       },
//       {
//         title: "Sequence 16",
//         url: "",
//         platform: "",
//         date: "2023年12月17日",
//       slug: ""
//       },
//       {
//         title: "PEDRAM Mitinoku's Birthday Party",
//         url: "",
//         platform: "",
//         date: "2023年12月28日",
//       slug: ""
//       },
//     ]
//   },
//   {
//     year: "2024",
//     events: [
//       {
//         title: "Club&Bar羽ばたき",
//         url: "",
//         platform: "",
//         date: "2024年1月4日",
//       slug: ""
//       },
//       {
//         title: "The 2nd Anniversary Day 1",
//         url: "",
//         platform: "",
//         date: "2024年1月6日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.36",
//         url: "",
//         platform: "",
//         date: "2024年1月12日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年1月26日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2024年1月31日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #176",
//         url: "",
//         platform: "",
//         date: "2024年2月1日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 195th",
//         url: "",
//         platform: "",
//         date: "2024年2月5日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.101",
//         url: "",
//         platform: "",
//         date: "2024年2月8日",
//       slug: ""
//       },
//       {
//         title: "あきぺ&とかげ誕生祭",
//         url: "",
//         platform: "",
//         date: "2024年3月1日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #182",
//         url: "",
//         platform: "",
//         date: "2024年3月14日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2024年4月3日",
//       slug: ""
//       },
//       {
//         title: "SUSHI HOUSE",
//         url: "",
//         platform: "",
//         date: "2024年4月9日",
//       slug: ""
//       },
//       {
//         title: "ごっつええFuture in VRCHat Ver.35.0",
//         url: "",
//         platform: "",
//         date: "2024年4月12日",
//       slug: ""
//       },
//       {
//         title: "SUSHI HOUSE",
//         url: "",
//         platform: "",
//         date: "2024年4月20日",
//       slug: ""
//       },
//       {
//         title: "SENSE//SENCE",
//         url: "",
//         platform: "",
//         date: "2024年4月20日",
//       slug: ""
//       },
//       {
//         title: "Re:construction Episode.1",
//         url: "",
//         platform: "",
//         date: "2024年4月24日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.114",
//         url: "",
//         platform: "",
//         date: "2024年5月9日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年5月11日",
//       slug: ""
//       },
//       {
//         title: "第71回 黒孔雀",
//         url: "",
//         platform: "",
//         date: "2024年5月16日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年5月19日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #193",
//         url: "",
//         platform: "",
//         date: "2024年5月30日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2024年6月5日",
//       slug: ""
//       },
//       {
//         title: "JUKu FfAi(r)Y",
//         url: "",
//         platform: "",
//         date: "2024年6月7日",
//       slug: ""
//       },
//       {
//         title: "mellon's afterlives #198",
//         url: "",
//         platform: "",
//         date: "2024年7月4日",
//       slug: ""
//       },
//       {
//         title: "冷感楽曲DJイベント 羽休め納涼祭",
//         url: "",
//         platform: "",
//         date: "2024年7月5日",
//       slug: ""
//       },
//       {
//         title: "Tokage Music Box #10",
//         url: "",
//         platform: "",
//         date: "2024年7月18日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年7月21日",
//       slug: ""
//       },
//       {
//         title: "FISHHEAD Party Vol.03 Day2",
//         url: "",
//         platform: "",
//         date: "2024年7月26日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研",
//         url: "",
//         platform: "",
//         date: "2024年7月31日",
//       slug: ""
//       },
//       {
//         title: "顕現「抵抗」",
//         url: "",
//         platform: "",
//         date: "2024年8月3日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE Summer ver Part.1",
//         url: "",
//         platform: "",
//         date: "2024年8月7日",
//       slug: ""
//       },
//       {
//         title: "mellon's aftrelives #203",
//         url: "",
//         platform: "",
//         date: "2024年8月8日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE Summner ver Part.2",
//         url: "",
//         platform: "",
//         date: "2024年8月15日",
//       slug: ""
//       },
//       {
//         title: "第十六回 創奏音楽祭",
//         url: "",
//         platform: "",
//         date: "2024年8月16日",
//       slug: ""
//       },
//       {
//         title: "CUERaider Vol.136 そわそわVRChat",
//         url: "",
//         platform: "",
//         date: "2024年8月29日",
//       slug: ""
//       },
//       {
//         title: "第79回 黒孔雀",
//         url: "",
//         platform: "",
//         date: "2024年9月5日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年9月7日",
//       slug: ""
//       },
//       {
//         title: "Goose Fruits",
//         url: "",
//         platform: "",
//         date: "2024年9月15日",
//       slug: ""
//       },
//       {
//         title: "ALT3",
//         url: "https://x.com/SANRIO_Vfes/status/1831258420571451805",
//         platform: "VRChat",
//         date: "2024年9月15日",
//       slug: ""
//       },
//       {
//         title: "VRでもボカクラにいきたいっ！",
//         url: "",
//         platform: "",
//         date: "2024年9月21日",
//       slug: ""
//       },
//       {
//         title: "第45回広義民族音楽オンリーイベント Mysnic Music of the World",
//         url: "",
//         platform: "",
//         date: "2024年9月25日",
//       slug: ""
//       },
//       {
//         title: "Club Silhouette",
//         url: "",
//         platform: "",
//         date: "2024年10月5日",
//       slug: ""
//       },
//       {
//         title: "mellon's aftrelives #212",
//         url: "",
//         platform: "",
//         date: "2024年10月10日",
//       slug: ""
//       },
//       {
//         title: "VJしたいっ vol.38",
//         url: "",
//         platform: "",
//         date: "2024年10月18日",
//       slug: ""
//       },
//       {
//         title: "Under Sea Music Event Vol.34",
//         url: "",
//         platform: "",
//         date: "2024年10月19日",
//       slug: ""
//       },
//       {
//         title: "CAT SANCTUARY",
//         url: "",
//         platform: "",
//         date: "2024年10月20日",
//       slug: ""
//       },
//       {
//         title: "MONDAY RELIEF 232nd",
//         url: "",
//         platform: "",
//         date: "2024年10月21日",
//       slug: ""
//       },
//       {
//         title: "VRC電音研 リアル課外活動 at CIRCUSTOKYO",
//         url: "",
//         platform: "",
//         date: "2024年10月26日",
//       slug: ""
//       },
//       {
//         title: "THE LUV BUGS",
//         url: "",
//         platform: "",
//         date: "2024年10月27日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん EP.139",
//         url: "",
//         platform: "",
//         date: "2024年10月31日",
//       slug: ""
//       },
//       {
//         title: "THE OUTSIDERS",
//         url: "",
//         platform: "",
//         date: "2024年11月3日",
//       slug: ""
//       },
//       {
//         title: "GOOD INTERNET 2 Release Party",
//         url: "",
//         platform: "",
//         date: "2024年11月4日",
//       slug: ""
//       },
//       {
//         title: "SUSHI HOUSE",
//         url: "",
//         platform: "",
//         date: "2024年11月5日",
//       slug: ""
//       },
//       {
//         title: "第20回 雑ボカ。 ～雑にボカロをかけれる会～",
//         url: "",
//         platform: "",
//         date: "2024年11月12日",
//       slug: ""
//       },
//       {
//         title: "Future Nova Vol.34",
//         url: "",
//         platform: "",
//         date: "2024年11月13日",
//       slug: ""
//       },
//       {
//         title: "CLUB SILHOUETTE",
//         url: "",
//         platform: "",
//         date: "2024年11月17日",
//       slug: ""
//       },
//       {
//         title: "Not Applicable vol.14",
//         url: "",
//         platform: "",
//         date: "2024年11月24日",
//       slug: ""
//       },
//       {
//         title: "Quest Danceparty Club no.184",
//         url: "",
//         platform: "",
//         date: "2024年12月3日",
//       slug: ""
//       },
//       {
//         title: "THE LUV BUGS in VRChat vol.1",
//         url: "",
//         platform: "",
//         date: "2024年12月5日",
//       slug: ""
//       },
//     ]
//   },
//   {
//     year: "2025",
//     events: [
//       {
//         title: "THE OUTSIDERS -THE END OF 2024 VR RAVE!!-",
//         url: "",
//         platform: "",
//         date: "2025年1月2日",
//       slug: ""
//       },
//       {
//         title: "The 3rd Anniversary Day1",
//         url: "",
//         platform: "",
//         date: "2025年1月18日",
//       slug: ""
//       },
//       {
//         title: "tèchne",
//         url: "",
//         platform: "",
//         date: "2025年1月19日",
//       slug: ""
//       },
//       {
//         title: "BUG COLLECTIVE",
//         url: "",
//         platform: "",
//         date: "2025年1月22日",
//       slug: ""
//       },
//       {
//         title: "DJなんもわからん 3rdAnniversary From:現実世界",
//         url: "",
//         url2: "https://twipla.jp/events/623051",
//         platform: "",
//         date: "2025年1月25日",
//       slug: ""
//       },
//       {
//         title: "Tomodachi Night in May.",
//         url: "",
//         platform: "VRChat",
//         date: "2025年5月11日",
//         slug: ""
//       },
//       {
//         title: "DEEP BLUE",
//         url: "https://x.com/lycoris60/status/1935638691751338325",
//         platform: "VRChat",
//         date: "2025年6月28日",
//         slug: ""
//       }
//     ]
//   }
// ];