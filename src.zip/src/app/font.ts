// import { Open_Sans, BIZ_UDPGothic, M_PLUS_1 } from "next/font/google";

// //Base English Font
// const fontBaseEn = Open_Sans(
//   {
//     subsets : ["latin", "latin-ext", "cyrillic", "cyrillic-ext", "greek", "hebrew", "greek-ext", "math", "symbols", "vietnamese"],
//     weight  : ["300", "400", "500", "600", "700", "800"],
//     variable: "--font-base-en",
//     display : "swap",
//   }
// );

// //Base Japanese Font
// const fontBaseJp = BIZ_UDPGothic(
//   {
//     subsets : ["latin", "latin-ext", "cyrillic", "greek-ext"],
//     weight  : ["400", "700"],
//     variable: "--font-base-jp",
//     display : "swap",
//   }
// );

// //Base Japanese Font
// const fontProfileJp = M_PLUS_1(
//   {
//     subsets : ["latin", "latin-ext", "vietnamese"],
//     weight  : ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
//     variable: "--font-profile-jp",
//     display : "swap",
//   }
// );

// const fontsBase = `${fontBaseJp.variable} ${fontBaseEn.variable} ${fontProfileJp.variable} antialiased`;
// export default fontsBase;