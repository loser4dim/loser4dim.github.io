"use client";
import TweetEmbed from "@/components/twitter/TweetEmbed";

export default function TweetList({ ids }: { ids: string[] }) {
  return (
    <>
      {
        ids.map(
          (id, i) => {
            return id ? (
              <div key={i} className="w-full flex justify-center">
                <TweetEmbed tweetId={id}/>
              </div>
            ) : (
              null
            );
          }
        )
      }
    </>
  );
}