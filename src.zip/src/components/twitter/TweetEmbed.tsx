"use client";
import { useEffect, useRef } from "react";

declare global {
  interface Window {
    twttr?: {
      widgets: {
        createTweet: (
          tweetId: string,
          element: HTMLElement,
          options?: Record<string, any>
        ) => Promise<HTMLElement>;
      };
    };
  }
}

export default function TweetEmbed({ tweetId }: { tweetId: string }) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // 💡 すでに描画済みなら何もしない（iframeがあれば描画済み）
    const already = el.querySelector("iframe");
    if (already) return;

    // 💡 twttrが使える状態でのみ描画
    if (window.twttr?.widgets?.createTweet) {
      window.twttr.widgets
        .createTweet(tweetId, el)
        .catch((err) => console.error("Tweet load failed", err));
    }
  }, [tweetId]);

  return <div ref={ref} className="flex justify-center min-h-[400px]" />;
}
