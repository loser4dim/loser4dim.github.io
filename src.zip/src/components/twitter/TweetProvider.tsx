"use client";
import { useEffect, useState } from "react";

export default function TweetProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const isLoaded = () =>
      typeof window !== "undefined" &&
      window.twttr &&
      window.twttr.widgets &&
      typeof window.twttr.widgets.createTweet === "function";

    if (isLoaded()) {
      setReady(true);
      return;
    }

    // 既に script タグが存在するが初期化中の場合
    if (document.querySelector("script[src='https://platform.twitter.com/widgets.js']")) {
      const interval = setInterval(() => {
        if (isLoaded()) {
          clearInterval(interval);
          setReady(true);
        }
      }, 100);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://platform.twitter.com/widgets.js";
    script.async = true;
    script.onload = () => {
      const wait = setInterval(() => {
        if (isLoaded()) {
          clearInterval(wait);
          setReady(true);
        }
      }, 50);
    };
    document.body.appendChild(script);
  }, []);

  return <>{ready ? children : null}</>;
}
